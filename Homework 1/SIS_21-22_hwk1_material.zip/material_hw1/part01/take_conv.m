%% Convolution function
% Kagan Erunsal, kagan.erunsal@epfl.ch, Oct 2021

% first_signal: first signal as vector or function
% second_signal: second signal as vector or function
% aux_var: Any auxillary variable you might need
% result: convolution result as vector
function  result = take_conv(first_signal,second_signal,aux_var)

result = 0;

end