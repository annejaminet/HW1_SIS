%% part01: Convolution
% Kagan Erunsal, kagan.erunsal@epfl.ch, Oct 2021

%% Q1
n = -50:1:50;

% a)


% b)
% result = take_conv(first_signal,second_signal,aux_var);