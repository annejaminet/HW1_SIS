%% part03 (System theory)
% Kagan Erunsal, kagan.erunsal@epfl.ch, Oct 2021

%% Q11 (use ilaplace())

%% Q12

% a (use tf() and step())


% b (use int())

%% Q13


%% Q14 (use c2d())


%% Q15 (use iztrans())


%% Q16 (use fft())


%% Q17 (use lsim())
