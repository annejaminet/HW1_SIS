function [ts,ys]=sample_data(t,y,Fs)
% SAMPLE_DATA: sample signal y at frequency Fs
% ts: sampled timeline
% ys: sampled data
% t: original timeline
% y: original data
% Fs: sampling frequency

end
