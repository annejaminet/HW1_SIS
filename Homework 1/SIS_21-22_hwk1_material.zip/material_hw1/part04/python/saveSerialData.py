import serial

arduino_port = "/dev/ttyUSB0" #serial port of Arduino
baud = 9600 #arduino MEGA runs at 9600 baud
fileName="earthquake_data.txt" #name of the CSV file generated

